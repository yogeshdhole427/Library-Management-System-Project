-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2023 at 11:54 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_details`
--

CREATE TABLE `book_details` (
  `book_name` varchar(50) NOT NULL,
  `b_category` varchar(50) NOT NULL,
  `b_author` varchar(50) NOT NULL,
  `b_publisher` varchar(50) NOT NULL,
  `b_pages` int(20) NOT NULL,
  `b_qty` int(20) NOT NULL,
  `b_edition` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_details`
--

INSERT INTO `book_details` (`book_name`, `b_category`, `b_author`, `b_publisher`, `b_pages`, `b_qty`, `b_edition`) VALUES
('Java', 'Educational', 'xyz', 'abc', 300, 4, 2023),
('software testing', 'Educational', 'xyz', 'abc', 200, 10, 2023),
('python', 'Educational', 'xyz', 'abc', 100, 15, 2022);

-- --------------------------------------------------------

--
-- Table structure for table `issue_details`
--

CREATE TABLE `issue_details` (
  `s_name` varchar(50) NOT NULL,
  `s_rollno` int(10) NOT NULL,
  `s_class` varchar(10) NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `b_author` varchar(50) NOT NULL,
  `issue_date` varchar(20) NOT NULL,
  `retuurn_date` varchar(20) NOT NULL,
  `returned` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issue_details`
--

INSERT INTO `issue_details` (`s_name`, `s_rollno`, `s_class`, `book_name`, `b_author`, `issue_date`, `retuurn_date`, `returned`) VALUES
('Yogesh Dhole', 39, 'TYBCA', 'java', 'xyz', '27/11/2023', '1December2023', 'Not Returned');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `total_students` int(30) NOT NULL,
  `total_books` int(30) NOT NULL,
  `t_issuedbooks` int(30) NOT NULL,
  `t_returnedbooks` int(30) NOT NULL,
  `t_availablebooks` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`total_students`, `total_books`, `t_issuedbooks`, `t_returnedbooks`, `t_availablebooks`) VALUES
(2, 30, 1, 0, 29);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `s_name` varchar(50) NOT NULL,
  `s_class` varchar(50) NOT NULL,
  `s_rollno` int(30) NOT NULL,
  `s_gender` varchar(10) NOT NULL,
  `s_phno` int(10) NOT NULL,
  `s_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_name`, `s_class`, `s_rollno`, `s_gender`, `s_phno`, `s_email`) VALUES
('Yogesh Dhole', 'TYBCA', 39, 'Male', 1234567890, 'yogesh@gmail.com'),
('Jayesh', 'TYBBA', 45, 'Male', 1234567890, 'jay@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
